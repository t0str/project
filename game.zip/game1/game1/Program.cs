﻿using System;

namespace Game
{

    class Program
    {

        static void Pravila()
        {
            Console.WriteLine("Нажмите Tab, чтобы посмотреть правила, нажмите любую другую кнопку чтобы начать игру сразу");
            Console.WriteLine();
            if (Console.ReadKey(true).Key == ConsoleKey.Tab)
            {
                Console.WriteLine("1.Выбираете количество цифр сколько будет в числе(от 1 до 10).");
                Console.WriteLine("2.Компьютер загадывает число с количеством цифр введеным ранее такое, что все цифры в нём различные.");
                Console.Write("3.Далее вы пытаетесь угадать число которое загадал компьютер, ");
                Console.WriteLine("вводя число с количеством цифр указанным ранее и в котором все цифры различны.");
                Console.WriteLine("4.Компьютер выдаёт количество коров и быков.");
                Console.WriteLine("5.Бык означает, что угадана цифра и она стоит на нужном месте.");
                Console.WriteLine("6.Корова означает, что угадана цифра, но она стоит не на своём месте.");
                Console.WriteLine("7.Игра заканчивается, когда вы отгадаете число.");
                Console.WriteLine();
            }
        }
        // При нажатии Tab выводятся правила игры.

        static void Numberdigit(out int number)
        {
            string input1;
            do
            {
                Console.Write("Введите количество цифр в числе(от 1 до 10):");
                input1 = Console.ReadLine();
                if (!int.TryParse(input1, out number))
                {
                    Console.WriteLine("Неправильные входные данные: Введённое значение не является типом int.");
                }
                // Проверка является ли введенное значением число типа int.
                else
                {
                    if ((number < 1) || (number > 10))
                    {
                        Console.WriteLine("Неправильные входные данные: Число не принадлежит промежутку от 1 до 10.");
                    }
                    // Если это число проверяем лежит ли оно на промежутке от 1 до 10.
                }
            } while ((!int.TryParse(input1, out number)) || (number < 1) || (number > 10));
            // Повторяем до тех пор пока пользователь не введёт подходящее значение.
        }

        static long[] Random(ref int number)
        {
            long[] digitsRandom = new long[number];
            int repetitions;
            long valueRandom;
            Random rng = new Random();
            do
            {
                repetitions = 0;
                if (number > 9)
                {
                    long u = rng.Next(10, 100);
                    valueRandom = u * (long)Math.Pow(10, 8) + rng.Next((int)Math.Pow(10, 7), (int)Math.Pow(10, 8));
                }
                // Если число 10-значное, то компьютер генерирует сначала двузначное число, которое будет стоять в начале числа,
                // а потом 8-значное число которое будет стоять в конце исходного числа.
                else
                {
                    valueRandom = rng.Next((int)Math.Pow(10, number - 1), (int)Math.Pow(10, number));
                }
                // Если число состоит из меньше 10 цифр, то мы генерируем число состоящее из нужного количества цифр.
                // Делаем так потому что компьютер может генерировать только числа типа int32, следовательно не все 10-значные числа
                // смогут быть сгенерированы.
                for (int index = 0; index < number; index++)
                {
                    digitsRandom[index] = (valueRandom / (int)Math.Pow(10, index)) % 10;
                }
                // Каждую цифру сгенерированного числа заносим в массив.
                for (int index = 0; index < number - 1; index++)
                {
                    for (int index2 = index + 1; index2 < number; index2++)
                    {
                        if (digitsRandom[index] == digitsRandom[index2])
                        {
                            repetitions++;
                        }
                    }
                }
                // Подсчитываем количество повторов цифр в числе.
            } while (repetitions > 0);
            // Повторяем пока в сгенерированном числе не будет повторов цифр.
            return digitsRandom;
        }

        static long[] Digits(ref long valueUser, ref int number, out long repetitions, ref long[] digitsUser)
        {
            repetitions = 0;
            for (int index = 0; index < number; index++)
            {
                digitsUser[index] = (valueUser / (int)Math.Pow(10, index)) % 10;
            } 
            // Каждую цифру введённого пользователем числа заносим в массив.
            for (int index = 0; index < number - 1; index++)
            {
                for (int index2 = index + 1; index2 < number; index2++)
                {
                    if (digitsUser[index] == digitsUser[index2])
                    {
                        repetitions++;
                    }
                }
            } 
            // Считаем количество повторов цифр в числе.
            return digitsUser;
        }

        private static void BullsandCows(ref long[] digitsUser, ref long[] digitsRandom, ref int number, out long cows, out long bulls)
        {
            bulls = 0;
            cows = 0;
            for (int index = 0; index < number; index++)
            {
                if (digitsRandom[index] == digitsUser[index])
                {
                    bulls++;
                }
            } 
            // Считаем сколько совпадающих цифр стоят на нужных местах и записываем значение в переменную bulls.
            for (int index = 0; index < number - 1; index++)
            {
                for (int index2 = index + 1; index2 < number; index2++)
                {
                    if (digitsUser[index] == digitsRandom[index2])
                    {
                        cows++;
                    }
                }
            } 
            // Считаем сколько совпадающих цифр стоят на местах имеющих номер меньше, чем у загаданного и записываем значение
            // в переменную cows.
            for (int index = number - 1; index > 0; index--)
            {
                for (int index2 = index - 1; index2 >= 0; index2--)
                {
                    if (digitsUser[index] == digitsRandom[index2])
                    {
                        cows++;
                    }
                }
            } 
            // Считаем сколько совпадающих цифр стоят на местах имеющих номер больше, чем у загаданного и прибавляем к ранее 
            // посчитанному числу коров, получая общее количество коров в числе.
        }

        static void Main(string[] args)
        {
            Pravila();
            do
            {
                long bulls;
                long cows;
                long valueUser;
                long repetitions;
                int number;
                Numberdigit(out number);
                long[] digitsRandom = new long[number];
                digitsRandom = Random(ref number);
                do
                {
                    bulls = 0;
                    Console.Write($"Введите {number}-значное число:");
                    string input = Console.ReadLine();
                    if (!long.TryParse(input, out valueUser)) 
                        // Проверка является ли введённое число типом long.
                    {
                        Console.WriteLine("Неправильные входные данные: Введённое значение не является типом long.");
                    }
                    else
                    {
                        // Далее проверка нужное ли количество цифр в введённом числе.
                        if ((valueUser < (long)Math.Pow(10, number - 1)) || (valueUser >= (long)Math.Pow(10, number)))
                        {
                            Console.WriteLine($"Неправильные входные данные: число не является {number}-значным.");
                        }
                        else
                        {
                            long[] digitsUser = new long[number];
                            digitsUser = Digits(ref valueUser, ref number, out repetitions, ref digitsUser);
                            // В Digits была проверка если в числе нет повторяющихся чисел, то repetitions = 0.
                            if (repetitions != 0)
                            {
                                Console.WriteLine("Неправильные входные данные: В введеном числе не должно быть повторяющихся чисел.");
                            } 
                            else
                            {
                                BullsandCows(ref digitsUser, ref digitsRandom, ref number, out cows, out bulls);
                                Console.WriteLine($"быков: {bulls}");
                                Console.WriteLine($"коров: {cows}");
                            } 
                            // Если есть повторения выводим ошибку, иначе выводим количество коров и быков в числе.
                        }
                    }
                } while (bulls != number);
                Console.WriteLine("Для выхода нажмите - Escape, для игры заново нажмите любую другую клавишу.");
                Console.WriteLine();
            } while (Console.ReadKey(true).Key != ConsoleKey.Escape); 
            // Проверяем хочет ли пользователь закончить игру или начать заново.
        }
    }
}
